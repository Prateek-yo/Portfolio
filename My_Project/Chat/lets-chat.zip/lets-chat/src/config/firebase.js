// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDuwqB17nyjAj8Y0SDYPVpnip0SPoVC2Eg",
  authDomain: "hi-synk.firebaseapp.com",
  projectId: "hi-synk",
  storageBucket: "hi-synk.firebasestorage.com",
  messagingSenderId: "949541494465",
  appId: "1:949541494465:web:70d748dd0207c38f103e40"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);